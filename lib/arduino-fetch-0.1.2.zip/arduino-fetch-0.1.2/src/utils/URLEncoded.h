class URLEncoded {
    URLEncoded();
};